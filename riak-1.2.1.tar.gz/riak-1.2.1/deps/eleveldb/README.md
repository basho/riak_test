# `eleveldb` - Erlang bindings to LevelDB datastore 

[![Build Status](https://secure.travis-ci.org/basho/eleveldb.png?branch=master)](http://travis-ci.org/basho/eleveldb)
